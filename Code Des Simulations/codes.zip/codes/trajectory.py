# -*- coding: utf-8 -*-
"""
Hackathon 2020
Trajectory
Myriam Prasow-Émond
"""

# =============================================================================
# IMPORTATIONS
# =============================================================================

import matplotlib.pyplot as plt
import numpy as np
import math
from celluloid import Camera

# =============================================================================
# INITIAL CONDITIONS
# =============================================================================

mode = input('Please enter the mode (angle, speed, or gravity): ')
mode = str(mode)
number_of_objects = 3
deltat = 0.01

#UTILISATOR
if mode == "angle":

    x0 = 0.
    y0 = 0.
    t0 = 0.
    v0 = 5.
    g = -9.81
    initial = np.array([x0, y0, t0, v0, 45., g])
    initial2 = np.array([x0, y0, t0, v0, 30., g])
    initial3 = np.array([x0, y0, t0, v0, 70., g])
    values = np.array([45, 30, 70])

if mode == "speed":

    x0 = 0.
    y0 = 0.
    t0 = 0.
    theta0 = 45.
    g = -9.81
    initial = np.array([x0, y0, t0, 10, theta0, g])
    initial2 = np.array([x0, y0, t0, 5, theta0, g])
    initial3 = np.array([x0, y0, t0, 3, theta0, g])    
    values = np.array(["10 m/s", "5 m/s", "3 m/s"])
    
if mode == "gravity":

    x0 = 0.
    y0 = 0.
    t0 = 0.
    v0 = 5.
    theta0 = 45.
    initial = np.array([x0, y0, t0, v0, theta0, -9.81])
    initial2 = np.array([x0, y0, t0, v0, theta0, -1.62])
    initial3 = np.array([x0, y0, t0, v0, theta0, -3.711]) 
    values = np.array(['Earth', 'Moon', 'Mars'])
    
# =============================================================================
# TRAJECTORY FUNCTION
# =============================================================================

class trajectory:
    def __init__(self, initial, deltat):   
        self.g = initial[5] #m/s^2
        self.x0 = initial[0]
        self.y0 = initial[1]
        self.x = x0
        self.y = y0
        self.t0 = initial[2]
        self.t = t0
        self.v0 = initial[3]
        self.theta0 = initial[4]
        self.dt = deltat
        self.v0x = self.v0*np.cos(math.radians(self.theta0))
        self.v0y = self.v0*np.sin(math.radians(self.theta0))
        self.traj_time = self.t0 - 2*self.v0y/self.g
        self.t_max = -self.v0y/self.g
        self.tpast = self.t0
        self.x_max = self.t0 + self.v0x*self.traj_time
        self.y_max = self.y0 + self.v0y*self.t_max + 0.5*self.g*self.t_max**2

    def trajectory_x(self):
        if self.y0 >= 0: 
            self.x = self.x0 + self.v0x*self.dt
            self.x0 = self.x
            return self.x
        else:
            self.x = self.x
            return self.x
    
    def trajectory_y(self):
        if self.y0 >= 0:                
            self.y = self.y0 + self.v0y*self.dt + 0.5*self.g*self.dt**2
            self.vy = self.v0y + self.g*self.dt
            self.v0y = self.vy
            self.y0 = self.y
            return self.y
        else:
            self.y = 0
            return self.y
    
    def update_time(self):
        self.t = self.tpast + self.dt
        self.tpast = self.t
    
    # def __main__(self):

#For the animation
fig = plt.figure()
camera = Camera(fig)
        
pos_x1 = []
pos_y1 = []
time1 = []
pos_x2 = []
pos_y2 = []
time2 = []
pos_x3 = []
pos_y3 = []
time3 = []
#var = [trajectory(initial, deltat), trajectory(initial2, deltat), trajectory(initial3, deltat)]
var1 = trajectory(initial, deltat)
var2 = trajectory(initial2, deltat)
var3 = trajectory(initial3, deltat)

x_max = np.array([var1.x_max, var2.x_max, var3.x_max])
y_max = np.array([var1.y_max, var2.y_max, var3.y_max])
traj = np.array([var1.traj_time, var2.traj_time, var3.traj_time])

while var1.t < np.max(traj):
    
    #for i in range(1, number_of_objects+1):

    pos_x1.append(var1.trajectory_x())
    pos_y1.append(var1.trajectory_y())
    time1.append(var1.t)
    var1.update_time()

    pos_x2.append(var2.trajectory_x())
    pos_y2.append(var2.trajectory_y())
    time2.append(var2.t)
    var2.update_time()

    pos_x3.append(var3.trajectory_x())
    pos_y3.append(var3.trajectory_y())
    time3.append(var3.t)
    var3.update_time()
    
    with plt.xkcd():
       
        plt.plot(pos_x3, pos_y3, ls = "--", color = "black")
        plt.plot(pos_x3[-1], pos_y3[-1], color = "b", markersize = 12, marker = "o")
        if mode == "angle":
            plt.text(pos_x3[-1], pos_y3[-1]+0.05, str(int(var3.theta0))+r"$^o$")
            plt.text(pos_x1[-1], pos_y1[-1]+0.05, str(int(var1.theta0))+r"$^o$")
            plt.text(pos_x2[-1], pos_y2[-1]+0.05, str(int(var2.theta0))+r"$^o$")
        if mode == "gravity":
            plt.text(pos_x3[-1], pos_y3[-1]+0.05, values[2])
            plt.text(pos_x1[-1], pos_y1[-1]+0.05, values[0])
            plt.text(pos_x2[-1], pos_y2[-1]+0.05, values[1])            
        if mode == "speed":
            plt.text(pos_x3[-1], pos_y3[-1]+0.05, values[2])
            plt.text(pos_x1[-1], pos_y1[-1]+0.05, values[0])
            plt.text(pos_x2[-1], pos_y2[-1]+0.05, values[1])   
        plt.plot(pos_x1, pos_y1, ls = "--", color = "black")
        plt.plot(pos_x1[-1], pos_y1[-1], color = "g", markersize = 12, marker = "o")#, label = str(int(var.theta0))+r"$^o$")
        plt.plot(pos_x2, pos_y2, ls = "--", color = "black")
        plt.plot(pos_x2[-1], pos_y2[-1], color = "r", markersize = 12, marker = "o")#, label = str(int(var2.theta0))+r"$^o$")
        plt.xlim(0, np.max(x_max)+0.2)
        plt.ylim(0, np.max(y_max)+0.2)
        plt.xlabel("x (m)")
        plt.ylabel("y (m)")
        plt.text(np.max(x_max)-0.3*np.max(x_max)+0.1, np.max(y_max)-0.3*np.max(y_max)+0.1, "t = "+str(np.round(var3.t, 3))+" s")
        plt.tight_layout()
        camera.snap()

animation = camera.animate(interval = 20)
animation.save('animation.mp4')
