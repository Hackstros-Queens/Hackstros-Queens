# -*- coding: utf-8 -*-
"""
Created on Sat Nov  7 20:00:56 2020

@author: Myriam Prasow-Émond
"""

# =============================================================================
# IMPORTATIONS
# =============================================================================

import matplotlib.pyplot as plt
import numpy as np
import math
from celluloid import Camera
import matplotlib.patches as pat
from matplotlib.offsetbox import TextArea, DrawingArea, OffsetImage, AnnotationBbox
import matplotlib.image as mpimg

# =============================================================================
# CONDITIONS
# =============================================================================

c = 3e8
L0 = 4
v_spaceship = 0.8
dt = 0.1 #years

initial = np.array([v_spaceship, L0, dt])

class relativity:
    def __init__(self, initial):
        self.v = initial[0]
        self.c = c
        self.dt = initial[2]
        self.gamma = 1/np.sqrt(1-(self.v)**2)
        self.L0 = initial[1]
        self.L = self.L0/self.gamma
        self.t = 0 #self.L0/self.v
        self.t0 = 0 #self.t/self.gamma
        self.dt0 = self.dt/self.gamma
        self.x = 0
        self.y = 0
    
    def update_pos(self):
        if self.x < self.L0:
            self.x = self.x + self.v*self.dt

        if self.x > self.L0:
            self.v = -1*self.v
            self.x = self.x + self.v*self.dt
    
    def update_time(self):
        self.t = self.t + self.dt
        self.t0 = self.t0 + self.dt0


    
var = relativity(initial)
pos_x = []
pos_y = []
t_terre = []
t_ship = []

fig = plt.figure()
camera = Camera(fig)

while var.t <= 2*var.L0/abs(var.v):
    
    pos_x.append(var.x)
    pos_y.append(var.y)
    t_terre.append(var.t)
    t_ship.append(var.t0)
    var.update_pos()
    var.update_time()
    
    
    with plt.xkcd():
        plt.plot(pos_x, pos_y, ls = "--", color = "black")
        if var.t <= var.L0/abs(var.v):
            plt.plot(pos_x[-1], pos_y[-1], color = "gray", markersize = 35, marker = "4", mec = "k")
        else:
            plt.plot(pos_x[-1], pos_y[-1], color = "gray", markersize = 35, marker = "3", mec = "k")
        plt.xlim(-1, var.L0 +1)
        plt.plot(var.L0, 0, marker = "*", color = "gold", markersize = 30, mec = "k")
        plt.plot(0, 0, marker = "o", color = "darkturquoise", mec = "k", markersize = 30)
        plt.text(-0.2, 0.04, "Age of the twin on Earth: "+str(int(20 + var.t))+" years old")
        plt.text(-0.2, 0.03, "Age of the twin on the spaceship: "+str(int(20 + var.t0))+" years old")
        plt.text(var.L0 - 0.3*var.L0, -0.02, "Distance from Earth:")
        plt.text(var.L0 - 0.3*var.L0, -0.03, str(int(var.L0))+" light-years", color = "r")
        plt.text(var.L0 - 0.3*var.L0, -0.04, "Speed of the spaceship:")
        plt.text(var.L0 - 0.3*var.L0, -0.05, str(int(v_spaceship*100))+"% of the speed of light", color = "r")
        plt.axis("off")
        plt.tight_layout()
        camera.snap()

animation = camera.animate(interval = 150)
animation.save('twin_paradox.mp4')
        