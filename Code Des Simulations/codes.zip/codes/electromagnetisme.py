# -*- coding: utf-8 -*-
"""
Created on Sat Nov  7 23:36:20 2020

@author: myria
"""
# =============================================================================
# IMPORTATIONS
# =============================================================================

import matplotlib.pyplot as plt
import numpy as np
import math
from celluloid import Camera
import matplotlib.patches as pat
from matplotlib.offsetbox import TextArea, DrawingArea, OffsetImage, AnnotationBbox
import matplotlib.image as mpimg

# =============================================================================
# CONDITIONS
# =============================================================================

pos = np.array([0, 0, 0])
v = np.array([1, 1, 1])
B = np.array([0, 0, 1])
q = 1
#Fm = q*np.cross(v, B)
mp = 1
#a = Fm/mp
dt = 0.1
sim_time = 20

#plt.quiver(phi, r, ux, uy)

class electromagnetism:
    def __init__(self, v, B, dt, q, m):
        self.v = v
        self.B = B
        self.dt = dt
        self.q = q
        self.m = m
        self.t = 0
        self.pos = pos
    
    def magnetic_force(self):
        self.Fm = self.q*np.cross(self.v, self.B)
        self.a = self.Fm/self.m
        self.v = self.v + self.a*self.dt
      
    def update_position(self):
        self.pos = self.pos + self.v*self.dt + 0.5*self.a*self.dt**2
              
    def update_time(self):
        self.t = self.t + self.dt

pos_x = []
pos_y = []
pos_z = []
t = []
fig = plt.figure()
ax = fig.add_subplot(111, projection = "3d")
var = electromagnetism(v, B, dt, q, mp)  
camera = Camera(fig)   
while var.t < sim_time:

    pos_x.append(var.pos[0])
    pos_y.append(var.pos[1])
    pos_z.append(var.pos[2])
    t.append(var.t)
    var.magnetic_force()
    var.update_position()
    var.update_time()
    
    #with plt.xkcd():
    x, y, z = np.meshgrid(np.linspace(-4, 4, 3), np.linspace(-4,4,3), np.linspace(0,20,3))
    ax.quiver(x, y, z, np.zeros(3), np.zeros(3), np.ones(3)*3, zorder = 16)
    #ax.set_axis_off()
    ax.scatter(pos_x[-1], pos_y[-1], pos_z[-1], marker = "o", color = "red", zorder =15)
    ax.plot(pos_x, pos_y, pos_z, ls = "--", color = "k")
    camera.snap()

animation = camera.animate(interval = 50)
animation.save('electromagnetism.mp4')
    