# -*- coding: utf-8 -*-
"""
Created on Sat Nov  7 20:00:56 2020

@author: Myriam Prasow-Émond
"""

# =============================================================================
# IMPORTATIONS
# =============================================================================

import matplotlib.pyplot as plt
import numpy as np
import math
from celluloid import Camera
import matplotlib.patches as pat

# =============================================================================
# CONDITIONS
# =============================================================================

v_spaceship = np.arange(0, 1, 0.01)#np.array([0, 0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9, 0.95, 0.99])

lightspeed = 3e8
L0 = 15


class relativity:
    def __init__(self, initial):
        self.v = initial[0]
        self.c = lightspeed
        self.gamma = 1/np.sqrt(1-self.v**2)
        self.L0 = initial[1]
        self.L = self.L0/self.gamma

fig = plt.figure()
camera = Camera(fig)
for i in range(len(v_spaceship)):
    initial = np.array([v_spaceship[i], L0])        
    var = relativity(initial)
    with plt.xkcd():
        plt.hlines(0, -var.L/2, var.L/2)
        plt.hlines(1, -var.L/2, var.L/2)
        plt.vlines(-var.L/2, 0, 1)
        plt.vlines(var.L/2, 0, 1)
        
        plt.hlines(0, -var.L0/2, var.L0/2, ls = "--", color = "k")
        plt.hlines(1, -var.L0/2, var.L0/2, ls = "--", color = "k")
        plt.vlines(-var.L0/2, 0, 1, ls = "--", color = "k")
        plt.vlines(var.L0/2, 0, 1, ls = "--", color = "k")
        
        plt.ylim(-1, 2)
        plt.xlim(-var.L0/2-1, var.L0/2 +1)        
        x = np.linspace(-var.L/2, var.L/2, 50)
        plt.fill_between(x, 0, 1, color = "darkcyan")
        plt.text(-6, -0.5, "Speed is "+str(int(var.v*100))+"% the speed of the light")
        
        if i < 30:
            plt.text(-7, 1.7, "The speed is too low to notice big differences")
            plt.text(-2.5, 1.5, "Classical limit", color = "r")
        if i > 30:
            plt.text(-7, 1.7, "The object is contracting due to relativity")
            plt.text(-3, 1.5, "Length contracting", color = "r")        
        camera.snap()

animation = camera.animate(interval = 150)
animation.save('relativity.mp4')
        
        